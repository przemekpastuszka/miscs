/*
 * Przemysław Pastuszka
 * nr albumu: 233 186
 * 
 * Zadanie na pracownię nr 3 z przedmiotu Sieci Komputerowe
 * 
 * 5/06/2011
 */

#ifndef PP_SERVER_START
#define PP_SERVER_START

// startuje serwer
int start_server(int port, int max_connections);

#endif
