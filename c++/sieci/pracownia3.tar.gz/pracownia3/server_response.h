/*
 * Przemysław Pastuszka
 * nr albumu: 233 186
 * 
 * Zadanie na pracownię nr 3 z przedmiotu Sieci Komputerowe
 * 
 * 5/06/2011
 */


#ifndef PP_SERVER_RESPONSE
#define PP_SERVER_RESPONSE

// obsłuż klienta, połączonego przy pomocy gniazda sd, w katalogu directory
void serve(int sd, char* directory);

#endif
